"""
방구석 약국 관리 프로그램 (GUI 버전)

사용 방법:
1. credentials.json 파일을 이 스크립트와 같은 폴더에 둔다.
2. BLOG_URL을 본인 블로그 주소로 수정한다 (아래 설정 부분).
3. posts 폴더를 만들고, 발행할 글 텍스트 파일을 넣는다.
4. 이 파일을 더블클릭하거나 "python manager.py"로 실행한다.
5. 뜨는 창에서 버튼을 눌러서 작업한다. (터미널 명령어 안 쳐도 됨)
"""

import os
import re
import json
import glob
import shutil
import base64
import pickle
import threading
import requests
import tkinter as tk
from tkinter import scrolledtext, messagebox
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

# ===== 설정 (본인 정보로 수정) =====
BLOG_URL = "https://bangpharmacy.blogspot.com/"
CREDENTIALS_FILE = "credentials.json"
TOKEN_FILE = "token.pickle"
POSTS_FOLDER = "posts"
POSTED_FOLDER = "posted"
SCOPES = ["https://www.googleapis.com/auth/blogger"]

GITHUB_CONFIG_FILE = "github_config.json"
CARD_INSERTS_FOLDER = "card_inserts"
CARD_INSERTED_FOLDER = "card_inserted"

# 게시물 본문에 삽입하는 모바일 최적화 CSS 식별용 마커 (중복 삽입 방지)
MOBILE_CSS_MARKER = "<!-- MOBILE_FONT_CSS_V1 -->"
MOBILE_CSS_BLOCK = (
    MOBILE_CSS_MARKER +
    "<style>"
    "@media screen and (max-width: 640px){"
    ".post-body,.post-body p,.post-body li{font-size:17px !important;line-height:1.7 !important;}"
    ".post-body a{font-size:16px !important;}"
    "}"
    "</style>"
)

COUPANG_DISCLOSURE_SMALL = (
    '<div style="text-align: center;">'
    '<span style="font-size: x-small;">'
    "이 포스팅은 쿠팡 파트너스 활동의 일환으로, "
    "이에 따른 일정액의 수수료를 제공받을 수 있습니다."
    "</span></div>"
)

# 글 맨 끝에 한 번만 삽입하는 "소용량 테스트구매 유도" 문구 (중복 삽입 방지 마커 포함)
TEST_PURCHASE_NOTE_MARKER = "<!-- TEST_PURCHASE_NOTE_V1 -->"
TEST_PURCHASE_NOTE_HTML = (
    TEST_PURCHASE_NOTE_MARKER +
    '<p style="margin-top:20px; padding:14px; background-color:#f7f7f7; border-radius:8px; '
    'color:#555; line-height:1.7;">'
    "<strong>참고로,</strong> TV 홈쇼핑에서는 보통 60포~120포 이상을 한 세트로 묶어 판매해 "
    "개당 단가는 낮아 보이지만, 실제로는 한 번에 목돈이 나가고 다 먹기 전에 유통기한이 지나버리는 "
    "경우도 적지 않습니다. 반면 이 글에 소개된 상품들은 대부분 1~2개월분 소용량 구성이라, "
    "아이 입맛에 맞는지·먹은 뒤 반응이 어떤지 먼저 확인해보는 '테스트 구매'에 부담이 적습니다. "
    "잘 맞는 걸 확인한 뒤에 대용량으로 넘어가도 늦지 않습니다."
    "</p>"
)

# 본문에 남아있는 "#태그,#태그,#태그" 형태의 해시태그 나열 줄을 찾기 위한 패턴
HASHTAG_BLOCK_PATTERN = re.compile(
    r'<p[^>]*>\s*(?:#[^\s,<]+\s*,\s*)+#[^\s,<]+\s*,?\s*</p>\s*',
    re.IGNORECASE
)
HASHTAG_INLINE_PATTERN = re.compile(
    r'(?:#[^\s,<]+\s*,\s*){1,}#[^\s,<]+',
    re.IGNORECASE
)

# 본문에서 지운 해시태그를 본문 텍스트 대신 Blogger 라벨(태그)로 다시 넣을 때 쓰는 기본 목록
DEFAULT_HASHTAG_LABELS = ["프로바이오틱스", "유산균", "여성유산균", "남성유산균", "갱년기유산균", "다이어트유산균"]



def get_service():
    creds = None
    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE, "rb") as token:
            creds = pickle.load(token)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_FILE, SCOPES)
            creds = flow.run_local_server(port=0)
        with open(TOKEN_FILE, "wb") as token:
            pickle.dump(creds, token)
    return build("blogger", "v3", credentials=creds)


def get_blog_id(service):
    result = service.blogs().getByUrl(url=BLOG_URL).execute()
    return result["id"]


def load_github_config():
    if not os.path.exists(GITHUB_CONFIG_FILE):
        raise FileNotFoundError(
            f"{GITHUB_CONFIG_FILE} 파일이 없습니다. username/repo/branch/token을 담은 파일을 만들어주세요."
        )
    with open(GITHUB_CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def upload_bytes_to_github(image_bytes, name_hint, github_cfg):
    """이미지 바이트를 GitHub 저장소에 업로드하고, 웹에서 접근 가능한 raw URL을 반환한다."""
    username = github_cfg["username"]
    repo = github_cfg["repo"]
    branch = github_cfg.get("branch", "main")
    token = github_cfg["token"]

    ext = os.path.splitext(name_hint)[1].split("?")[0] or ".jpg"
    if len(ext) > 5:  # 이상한 확장자 방지
        ext = ".jpg"
    safe_name = re.sub(r"[^a-zA-Z0-9_\-]", "_", os.path.splitext(os.path.basename(name_hint))[0])
    # 광고차단 필터가 걸릴 만한 단어(banner, affiliate 등)는 무해한 단어로 치환
    safe_name = re.sub(r"(banner|affiliate|ads?|widget|sponsor)", "img", safe_name, flags=re.IGNORECASE)
    if not safe_name:
        safe_name = "product"
    filename = f"{safe_name}{ext}"

    content_b64 = base64.b64encode(image_bytes).decode("utf-8")

    api_url = f"https://api.github.com/repos/{username}/{repo}/contents/images/{filename}"
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json",
    }

    # 같은 이름의 파일이 이미 있으면 GitHub가 기존 파일의 sha 값을 요구한다.
    # 없으면(404) 새 파일로 생성하고, 있으면 그 sha를 넣어 덮어쓴다.
    existing = requests.get(f"{api_url}?ref={branch}", headers=headers, timeout=15)
    sha = existing.json().get("sha") if existing.status_code == 200 else None

    data = {
        "message": f"add {filename}",
        "content": content_b64,
        "branch": branch,
    }
    if sha:
        data["sha"] = sha

    res = requests.put(api_url, headers=headers, json=data, timeout=30)
    if res.status_code not in (200, 201):
        raise RuntimeError(f"GitHub 업로드 실패 ({res.status_code}): {res.text[:300]}")

    return f"https://raw.githubusercontent.com/{username}/{repo}/{branch}/images/{filename}"


def upload_to_github(filepath, github_cfg):
    """로컬 이미지 파일을 GitHub에 업로드한다 (기존 방식, 하위 호환용)."""
    with open(filepath, "rb") as f:
        image_bytes = f.read()
    return upload_bytes_to_github(image_bytes, os.path.basename(filepath), github_cfg)


def download_and_upload_to_github(image_url, github_cfg):
    """원본 이미지 URL(쿠팡 CDN 등)에서 서버가 직접 다운로드한 뒤 GitHub에 업로드한다."""
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    }
    res = requests.get(image_url, headers=headers, timeout=20)
    if res.status_code != 200 or not res.content:
        raise RuntimeError(f"이미지 다운로드 실패 ({res.status_code}): {image_url}")

    name_hint = os.path.basename(image_url.split("?")[0]) or "product.jpg"
    return upload_bytes_to_github(res.content, name_hint, github_cfg)


def build_product_card_html(product, image_url):
    """상품 1개 정보를 받아 좌:텍스트 / 우:이미지 카드 HTML을 생성한다."""
    name = product.get("NAME", "")
    brand = product.get("BRAND", "")
    desc = product.get("DESC", "")
    link = product.get("LINK", "")

    rocket = product.get("ROCKET", "").strip().upper() in ("Y", "YES", "TRUE", "1")

    brand_html = f'<span style="font-size:0.9em; color:#777; font-weight:normal;"> ({brand})</span>' if brand else ""
    desc_html = desc.replace("\n", "<br>")

    # 가격은 실시간으로 계속 바뀌므로 본문에 숫자를 박아두지 않고,
    # 항상 아래 링크에서 확인하도록 짧게 안내만 한다.
    price_html = (
        '<span style="font-size:0.88em; color:#888;">'
        '정확한 가격은 아래 버튼을 눌러 확인하세요 (쿠폰·할인 적용 시 실시간으로 달라질 수 있어요)'
        '</span>'
    )

    button_label = f"{name} 로켓배송으로 내일받아보기"

    button_style = (
        "display:block; margin-top:15px; padding:14px; background-color:#e60000; color:#ffffff; "
        "font-size:16px; font-weight:bold; border-radius:6px; text-decoration:none; text-align:center;"
    )

    return f'''<!-- PRODCARD:{link} -->
<div style="margin-bottom:30px; padding:15px; border:1px solid #eee; border-radius:8px;">
  <div style="display:flex; flex-wrap:wrap; align-items:flex-start; justify-content:center; gap:20px;">
    <div style="flex:1; min-width:200px;">
      <p style="margin:0 0 6px 0; font-size:1.1em;"><strong>{name}</strong>{brand_html}</p>
      <p style="margin:0 0 8px 0; color:#555; line-height:1.6;">{desc_html}</p>
      <p style="margin:0;">{price_html}</p>

    </div>
    <div style="flex-shrink:0; text-align:center;">
      <a href="{link}" target="_blank" rel="nofollow sponsored">
        <img src="{image_url}" alt="{name}" width="120" height="240" style="border-radius:6px; display:block; margin:0 auto;">
      </a>
    </div>
  </div>
  <a href="{link}" target="_blank" rel="nofollow sponsored" style="{button_style}">{button_label}</a>
</div>
<!-- /PRODCARD -->'''


def parse_card_file(filepath):
    """card_inserts 폴더의 .txt 파일을 파싱한다.

    형식:
        SLUG: cfu
        IMAGE_DIR: 이미지/kids   (IMAGE 값이 로컬 파일명일 때만 사용, URL이면 무시됨)

        [상품1]
        NAME: 락토핏 생유산균 키즈
        BRAND: 종근당건강
        DESC: 보장균수 10억 CFU, 60포/2개월분
        PRICE_LOW: 18,540
        PRICE_HIGH: 30,910
        PRICE_BASIS: 60포 1통 기준
        ROCKET: Y
        IMAGE: https://static.coupangcdn.com/image/affiliate/banner/xxxx@2x.jpg
        LINK: https://link.coupang.com/a/e69nLmQNlQ

        [상품2]
        ...

    PRICE_LOW/PRICE_HIGH가 둘 다 있으면 "최저가~최고가" 범위로 표시하고,
    범위 데이터가 부족하면 PRICE(단일 참고가) 항목만 넣어도 된다. 아무 가격도
    없으면 "가격 확인불가"로 표시된다. ROCKET을 Y로 주면 버튼 문구에 "쿠팡
    로켓배송으로 구매하러가기"가 들어간다.
    IMAGE 항목은 http(s):// 로 시작하면 원본 URL로 간주해 서버가 직접
    다운로드한 뒤 GitHub에 재업로드한다. http로 시작하지 않으면 로컬 파일
    (IMAGE_DIR 기준 상대경로)로 취급한다.
    """
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    header, _, body = content.partition("[상품1]")
    header_lines = header.strip().split("\n")
    slug = ""
    image_dir = ""
    for line in header_lines:
        if line.startswith("SLUG:"):
            slug = line.replace("SLUG:", "").strip()
        elif line.startswith("IMAGE_DIR:"):
            image_dir = line.replace("IMAGE_DIR:", "").strip()

    blocks = re.split(r"\[상품\d+\]", "[상품1]" + body)
    products = []
    for block in blocks:
        block = block.strip()
        if not block:
            continue
        entry = {}
        for line in block.split("\n"):
            if ":" in line:
                key, _, val = line.partition(":")
                entry[key.strip().upper()] = val.strip()
        if entry.get("NAME"):
            products.append(entry)

    return slug, image_dir, products


def parse_post_file(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()
    parts = content.split("---", 1)
    header = parts[0]
    body = parts[1].strip() if len(parts) > 1 else ""
    title = ""
    labels = []
    for line in header.strip().split("\n"):
        if line.startswith("TITLE:"):
            title = line.replace("TITLE:", "").strip()
        elif line.startswith("LABELS:"):
            labels = [l.strip() for l in line.replace("LABELS:", "").split(",")]
    return title, labels, body


class App:
    def __init__(self, root):
        self.root = root
        root.title("방구석 약국 관리 프로그램")
        root.geometry("700x500")

        tk.Label(root, text="방구석 약국 관리 프로그램", font=("맑은 고딕", 16, "bold")).pack(pady=10)

        btn_frame = tk.Frame(root)
        btn_frame.pack(pady=5)

        tk.Button(btn_frame, text="새 글 발행 (posts 폴더)", width=25, height=2,
                  command=self.run_publish).grid(row=0, column=0, padx=5)
        tk.Button(btn_frame, text="쿠팡 문구 위치 수정 (기존 글 전체)", width=30, height=2,
                  command=self.run_fix_disclosure).grid(row=0, column=1, padx=5)
        tk.Button(btn_frame, text="전체 글 목록 보기 (제목+URL)", width=25, height=2,
                  command=self.run_list_posts).grid(row=0, column=2, padx=5)
        tk.Button(btn_frame, text="관련 글 링크 자동 연결", width=25, height=2,
                  command=self.run_auto_link).grid(row=1, column=0, padx=5, pady=5)
        tk.Button(btn_frame, text="쿠팡 상품 삽입 (inserts 폴더)", width=28, height=2,
                  command=self.run_insert_products).grid(row=1, column=1, padx=5, pady=5)
        tk.Button(btn_frame, text="쿠팡 이미지 표시 오류 수정 (전체 글)", width=32, height=2,
                  command=self.run_fix_images).grid(row=1, column=2, padx=5, pady=5)
        tk.Button(btn_frame, text="GitHub 업로드 + 카드형 상품 삽입 (card_inserts 폴더)", width=40, height=2,
                  command=self.run_insert_product_cards).grid(row=2, column=0, columnspan=2, padx=5, pady=5)
        tk.Button(btn_frame, text="모바일 폰트 확대 CSS 적용 (전체 글)", width=32, height=2,
                  command=self.run_add_mobile_css).grid(row=2, column=2, padx=5, pady=5)
        tk.Button(btn_frame, text="테스트구매 유도문구 추가 (전체 글)", width=32, height=2,
                  command=self.run_add_test_purchase_note).grid(row=3, column=0, padx=5, pady=5)
        tk.Button(btn_frame, text="해시태그 줄 제거 (전체 글)", width=32, height=2,
                  command=self.run_remove_hashtags).grid(row=3, column=1, padx=5, pady=5)
        tk.Button(btn_frame, text="해시태그를 라벨로 재등록 (전체 글)", width=32, height=2,
                  command=self.run_add_hashtag_labels).grid(row=3, column=2, padx=5, pady=5)

        tk.Label(root, text="실행 로그", font=("맑은 고딕", 10)).pack(anchor="w", padx=10)
        self.log_box = scrolledtext.ScrolledText(root, width=85, height=22)
        self.log_box.pack(padx=10, pady=5)

    def log(self, message):
        self.log_box.insert(tk.END, message + "\n")
        self.log_box.see(tk.END)
        self.root.update()

    def run_publish(self):
        threading.Thread(target=self.publish_posts, daemon=True).start()

    def run_fix_disclosure(self):
        threading.Thread(target=self.fix_disclosure, daemon=True).start()

    def run_list_posts(self):
        threading.Thread(target=self.list_posts, daemon=True).start()

    def run_auto_link(self):
        threading.Thread(target=self.auto_link, daemon=True).start()

    def run_insert_products(self):
        threading.Thread(target=self.insert_products, daemon=True).start()

    def run_fix_images(self):
        threading.Thread(target=self.fix_images, daemon=True).start()

    def run_insert_product_cards(self):
        threading.Thread(target=self.insert_product_cards, daemon=True).start()

    def run_add_mobile_css(self):
        threading.Thread(target=self.add_mobile_css, daemon=True).start()

    def run_add_test_purchase_note(self):
        threading.Thread(target=self.add_test_purchase_note, daemon=True).start()

    def run_remove_hashtags(self):
        threading.Thread(target=self.remove_hashtags, daemon=True).start()

    def run_add_hashtag_labels(self):
        threading.Thread(target=self.add_hashtag_labels, daemon=True).start()

    def insert_product_cards(self):
        self.log("=== GitHub 업로드 + 카드형 상품 삽입 시작 ===")
        try:
            if not os.path.exists(CARD_INSERTS_FOLDER):
                os.makedirs(CARD_INSERTS_FOLDER)
                self.log(f"{CARD_INSERTS_FOLDER} 폴더가 없어서 새로 만들었습니다. 파일을 넣고 다시 실행해주세요.")
                return
            if not os.path.exists(CARD_INSERTED_FOLDER):
                os.makedirs(CARD_INSERTED_FOLDER)

            try:
                github_cfg = load_github_config()
            except Exception as e:
                self.log(f"GitHub 설정 오류: {e}")
                return

            files = sorted(glob.glob(os.path.join(CARD_INSERTS_FOLDER, "*.txt")))
            if not files:
                self.log(f"{CARD_INSERTS_FOLDER} 폴더에 처리할 파일이 없습니다.")
                return

            service = get_service()
            blog_id = get_blog_id(service)

            posts = []
            request = service.posts().list(blogId=blog_id, maxResults=500)
            while request is not None:
                response = request.execute()
                posts.extend(response.get("items", []))
                request = service.posts().list_next(request, response)

            PLACEHOLDER = "(쿠팡 파트너스 상품 링크/위젯 삽입 영역)"

            for filepath in files:
                slug, image_dir, products = parse_card_file(filepath)
                if not slug or not products:
                    self.log(f"건너뜀 (형식 오류): {filepath}")
                    continue

                matched_post = None
                for post in posts:
                    if slug in post["url"]:
                        matched_post = post
                        break
                if not matched_post:
                    self.log(f"매칭 실패 (해당 URL 슬러그를 가진 글 없음): {slug}")
                    continue

                content = matched_post["content"]
                use_placeholder = PLACEHOLDER in content

                cards_html = []
                ok = True
                for product in products:
                    image_value = product.get("IMAGE", "")
                    if not image_value:
                        self.log(f"  IMAGE 값 없음 (상품: {product.get('NAME')})")
                        ok = False
                        break

                    try:
                        if image_value.startswith("http://") or image_value.startswith("https://"):
                            self.log(f"  원본 이미지 다운로드 중: {image_value}")
                            image_url = download_and_upload_to_github(image_value, github_cfg)
                        else:
                            local_image_path = os.path.join(image_dir, image_value) if image_dir else image_value
                            if not os.path.exists(local_image_path):
                                self.log(f"  이미지 파일 없음: {local_image_path} (상품: {product.get('NAME')})")
                                ok = False
                                break
                            self.log(f"  GitHub 업로드 중: {local_image_path}")
                            image_url = upload_to_github(local_image_path, github_cfg)
                        self.log(f"  업로드 완료 -> {image_url}")
                    except Exception as e:
                        self.log(f"  이미지 처리 실패: {image_value} / 오류: {e}")
                        ok = False
                        break
                    cards_html.append((product, build_product_card_html(product, image_url)))

                if not ok:
                    self.log(f"건너뜀 (이미지 업로드 문제로 카드 미삽입): {matched_post['title']}")
                    continue

                if use_placeholder:
                    combined_html = "\n".join(html for _, html in cards_html)
                    new_content = content.replace(PLACEHOLDER, combined_html)
                    changed_count = len(cards_html)
                else:
                    # 플레이스홀더가 없는 경우: 두 가지 케이스를 순서대로 시도한다.
                    # (1) 이미 새 카드(PRODCARD 마커 포함)가 들어가 있으면 통째로 교체 (템플릿 업데이트용)
                    # (2) 그게 없으면, 처음 상태 그대로인 옛 다이나믹 배너를 링크 기준으로 찾아 교체
                    new_content = content
                    changed_count = 0
                    for product, card_html in cards_html:
                        link = product.get("LINK", "")
                        name = product.get("NAME", "")
                        if not link:
                            continue

                        escaped_link = re.escape(link)

                        # (0) 예전 잘못된 부분교체로 남았을 수 있는 고아 텍스트 블록/중복 소개문단은
                        #     PRODCARD 매칭 여부와 관계없이 항상 먼저 청소한다.
                        if name:
                            escaped_name = re.escape(name)

                            orphan_div_pattern = re.compile(
                                r'<div[^>]*flex:\s*1[^>]*>\s*<p[^>]*>\s*<strong>' + escaped_name +
                                r'</strong>.*?</div>\s*',
                                re.DOTALL
                            )
                            new_content, removed_orphan = orphan_div_pattern.subn('', new_content, count=1)
                            if removed_orphan:
                                self.log(f"  고아 텍스트 블록 제거: {name}")

                            intro_pattern = re.compile(
                                r'<p[^>]*>\s*<strong>' + escaped_name + r'</strong>.*?</p>\s*',
                                re.DOTALL
                            )
                            new_content, removed_intro = intro_pattern.subn('', new_content, count=1)
                            if removed_intro:
                                self.log(f"  중복 소개 문단 제거: {name}")

                        # (1) 기존 PRODCARD 블록이 있는 경우: 마커 기준으로 통째로 교체
                        prodcard_pattern = re.compile(
                            r'<!-- PRODCARD:' + escaped_link + r' -->.*?<!-- /PRODCARD -->',
                            re.DOTALL
                        )
                        new_content, n = prodcard_pattern.subn(card_html, new_content, count=1)
                        if n > 0:
                            changed_count += 1
                            continue

                        old_block_pattern = re.compile(
                            r'<div[^>]*>\s*<a[^>]*href="' + escaped_link + r'"[^>]*>.*?</a>\s*</div>',
                            re.DOTALL
                        )
                        new_content, n = old_block_pattern.subn(card_html, new_content, count=1)
                        if n > 0:
                            changed_count += 1
                            continue

                        # (2) 위 두 가지 다 해당 안 되면: 완전히 새로운 상품이라는 뜻이므로
                        #     기존 글은 건드리지 않고, 카드를 글 끝부분(테스트구매 유도문구/고지문구 앞)에 추가한다.
                        insertion_marker = None
                        for marker in (TEST_PURCHASE_NOTE_MARKER, COUPANG_DISCLOSURE_SMALL):
                            if marker in new_content:
                                insertion_marker = marker
                                break
                        if insertion_marker:
                            new_content = new_content.replace(insertion_marker, card_html + "\n" + insertion_marker, 1)
                        else:
                            new_content = new_content.strip() + "\n" + card_html
                        changed_count += 1
                        self.log(f"  신규 카드로 글 끝부분에 추가: {product.get('NAME')}")

                if changed_count == 0:
                    self.log(f"건너뜀 (교체할 대상을 찾지 못함): {matched_post['title']}")
                    continue

                try:
                    service.posts().update(
                        blogId=blog_id, postId=matched_post["id"],
                        body={"kind": "blogger#post", "title": matched_post["title"], "content": new_content}
                    ).execute()
                    self.log(f"카드 삽입/교체 완료 ({changed_count}개 상품): {matched_post['title']}")
                    shutil.move(filepath, os.path.join(CARD_INSERTED_FOLDER, os.path.basename(filepath)))
                except Exception as e:
                    self.log(f"업데이트 실패: {matched_post['title']} / 오류: {e}")

            self.log("=== GitHub 업로드 + 카드형 상품 삽입 종료 ===\n")
        except Exception as e:
            self.log(f"전체 오류: {e}")

    def add_mobile_css(self):
        self.log("=== 모바일 폰트 확대 CSS 적용 시작 ===")
        try:
            service = get_service()
            blog_id = get_blog_id(service)

            posts = []
            request = service.posts().list(blogId=blog_id, maxResults=500)
            while request is not None:
                response = request.execute()
                posts.extend(response.get("items", []))
                request = service.posts().list_next(request, response)

            for post in posts:
                post_id = post["id"]
                title = post["title"]
                content = post["content"]

                if MOBILE_CSS_MARKER in content:
                    self.log(f"건너뜀 (이미 적용됨): {title}")
                    continue

                new_content = MOBILE_CSS_BLOCK + content
                try:
                    service.posts().update(
                        blogId=blog_id, postId=post_id,
                        body={"kind": "blogger#post", "title": title, "content": new_content}
                    ).execute()
                    self.log(f"CSS 적용 완료: {title}")
                except Exception as e:
                    self.log(f"업데이트 실패: {title} / 오류: {e}")

            self.log("=== 모바일 폰트 확대 CSS 적용 종료 ===\n")
            self.log("참고: 새 글을 발행할 때는 이 CSS가 자동으로 들어가지 않으니, 새 글 발행 후 이 버튼을 다시 눌러주세요.\n")
        except Exception as e:
            self.log(f"전체 오류: {e}")

    def add_test_purchase_note(self):
        self.log("=== 테스트구매 유도문구 추가 시작 ===")
        try:
            service = get_service()
            blog_id = get_blog_id(service)

            posts = []
            request = service.posts().list(blogId=blog_id, maxResults=500)
            while request is not None:
                response = request.execute()
                posts.extend(response.get("items", []))
                request = service.posts().list_next(request, response)

            for post in posts:
                post_id = post["id"]
                title = post["title"]
                content = post["content"]

                if TEST_PURCHASE_NOTE_MARKER in content:
                    self.log(f"건너뜀 (이미 적용됨): {title}")
                    continue

                # 쿠팡 파트너스 고지문구(COUPANG_DISCLOSURE_SMALL) 바로 앞에 삽입,
                # 고지문구가 없는 글이면 그냥 맨 끝에 삽입한다.
                if COUPANG_DISCLOSURE_SMALL in content:
                    new_content = content.replace(
                        COUPANG_DISCLOSURE_SMALL,
                        TEST_PURCHASE_NOTE_HTML + COUPANG_DISCLOSURE_SMALL
                    )
                else:
                    new_content = content.strip() + "\n\n" + TEST_PURCHASE_NOTE_HTML

                try:
                    service.posts().update(
                        blogId=blog_id, postId=post_id,
                        body={"kind": "blogger#post", "title": title, "content": new_content}
                    ).execute()
                    self.log(f"유도문구 추가 완료: {title}")
                except Exception as e:
                    self.log(f"업데이트 실패: {title} / 오류: {e}")

            self.log("=== 테스트구매 유도문구 추가 종료 ===\n")
        except Exception as e:
            self.log(f"전체 오류: {e}")

    def remove_hashtags(self):
        self.log("=== 해시태그 줄 제거 시작 ===")
        try:
            service = get_service()
            blog_id = get_blog_id(service)

            posts = []
            request = service.posts().list(blogId=blog_id, maxResults=500)
            while request is not None:
                response = request.execute()
                posts.extend(response.get("items", []))
                request = service.posts().list_next(request, response)

            for post in posts:
                post_id = post["id"]
                title = post["title"]
                content = post["content"]

                # 1) <p>#태그,#태그,...#태그</p> 형태로 통째로 감싸진 줄 제거
                new_content, n1 = HASHTAG_BLOCK_PATTERN.subn('', content)
                # 2) <p> 태그 없이 본문 중간에 남은 "#태그,#태그,..." 나열도 제거
                new_content, n2 = HASHTAG_INLINE_PATTERN.subn('', new_content)

                total = n1 + n2
                if total == 0:
                    self.log(f"건너뜀 (해시태그 없음): {title}")
                    continue

                try:
                    service.posts().update(
                        blogId=blog_id, postId=post_id,
                        body={"kind": "blogger#post", "title": title, "content": new_content}
                    ).execute()
                    self.log(f"해시태그 {total}곳 제거 완료: {title}")
                except Exception as e:
                    self.log(f"업데이트 실패: {title} / 오류: {e}")

            self.log("=== 해시태그 줄 제거 종료 ===\n")
        except Exception as e:
            self.log(f"전체 오류: {e}")

    def add_hashtag_labels(self):
        self.log("=== 해시태그를 라벨로 재등록 시작 ===")
        try:
            service = get_service()
            blog_id = get_blog_id(service)

            posts = []
            request = service.posts().list(blogId=blog_id, maxResults=500)
            while request is not None:
                response = request.execute()
                posts.extend(response.get("items", []))
                request = service.posts().list_next(request, response)

            for post in posts:
                post_id = post["id"]
                title = post["title"]
                content = post["content"]
                existing_labels = post.get("labels", [])

                merged_labels = list(existing_labels)
                added = []
                for label in DEFAULT_HASHTAG_LABELS:
                    if label not in merged_labels:
                        merged_labels.append(label)
                        added.append(label)

                if not added:
                    self.log(f"건너뜀 (이미 라벨 있음): {title}")
                    continue

                try:
                    service.posts().update(
                        blogId=blog_id, postId=post_id,
                        body={
                            "kind": "blogger#post",
                            "title": title,
                            "content": content,
                            "labels": merged_labels,
                        }
                    ).execute()
                    self.log(f"라벨 추가 완료 ({', '.join(added)}): {title}")
                except Exception as e:
                    self.log(f"업데이트 실패: {title} / 오류: {e}")

            self.log("=== 해시태그를 라벨로 재등록 종료 ===\n")
        except Exception as e:
            self.log(f"전체 오류: {e}")

    def fix_images(self):
        self.log("=== 쿠팡 이미지 표시 오류 수정 시작 ===")
        try:
            service = get_service()
            blog_id = get_blog_id(service)

            posts = []
            request = service.posts().list(blogId=blog_id, maxResults=500)
            while request is not None:
                response = request.execute()
                posts.extend(response.get("items", []))
                request = service.posts().list_next(request, response)

            # coupangcdn.com 이미지를 가진 <img> 태그 중 referrerpolicy가 없는 것을 찾아 추가
            img_pattern = re.compile(r'<img\s+([^>]*coupangcdn\.com[^>]*)>', re.IGNORECASE)

            for post in posts:
                post_id = post["id"]
                title = post["title"]
                content = post["content"]

                def fix_tag(match):
                    attrs = match.group(1)
                    if "referrerpolicy" in attrs.lower():
                        return match.group(0)
                    return f'<img {attrs} referrerpolicy="unsafe-url">'

                new_content, count = img_pattern.subn(fix_tag, content)

                if count > 0 and new_content != content:
                    try:
                        service.posts().update(
                            blogId=blog_id, postId=post_id,
                            body={"kind": "blogger#post", "title": title, "content": new_content}
                        ).execute()
                        self.log(f"이미지 {count}개 수정 완료: {title}")
                    except Exception as e:
                        self.log(f"업데이트 실패: {title} / 오류: {e}")
                else:
                    self.log(f"건너뜀 (수정 대상 없음): {title}")

            self.log("=== 쿠팡 이미지 표시 오류 수정 종료 ===\n")
        except Exception as e:
            self.log(f"전체 오류: {e}")

    def insert_products(self):
        self.log("=== 쿠팡 상품 삽입 시작 (inserts 폴더) ===")
        try:
            INSERTS_FOLDER = "inserts"
            INSERTED_FOLDER = "inserted"
            if not os.path.exists(INSERTS_FOLDER):
                os.makedirs(INSERTS_FOLDER)
                self.log("inserts 폴더가 없어서 새로 만들었습니다. 파일을 넣고 다시 실행해주세요.")
                return
            if not os.path.exists(INSERTED_FOLDER):
                os.makedirs(INSERTED_FOLDER)

            files = sorted(glob.glob(os.path.join(INSERTS_FOLDER, "*.txt")))
            if not files:
                self.log("inserts 폴더에 처리할 파일이 없습니다.")
                return

            service = get_service()
            blog_id = get_blog_id(service)

            posts = []
            request = service.posts().list(blogId=blog_id, maxResults=500)
            while request is not None:
                response = request.execute()
                posts.extend(response.get("items", []))
                request = service.posts().list_next(request, response)

            PLACEHOLDER = "(쿠팡 파트너스 상품 링크/위젯 삽입 영역)"

            for filepath in files:
                slug = os.path.splitext(os.path.basename(filepath))[0]
                with open(filepath, "r", encoding="utf-8") as f:
                    insert_html = f.read()

                matched_post = None
                for post in posts:
                    if slug in post["url"]:
                        matched_post = post
                        break

                if not matched_post:
                    self.log(f"매칭 실패 (해당 URL 슬러그를 가진 글 없음): {slug}")
                    continue

                content = matched_post["content"]
                if PLACEHOLDER not in content:
                    self.log(f"건너뜀 (플레이스홀더 없음, 이미 처리됐을 수 있음): {matched_post['title']}")
                    continue

                new_content = content.replace(PLACEHOLDER, insert_html)
                try:
                    service.posts().update(
                        blogId=blog_id, postId=matched_post["id"],
                        body={"kind": "blogger#post", "title": matched_post["title"], "content": new_content}
                    ).execute()
                    self.log(f"삽입 완료: {matched_post['title']}")
                    shutil.move(filepath, os.path.join(INSERTED_FOLDER, os.path.basename(filepath)))
                except Exception as e:
                    self.log(f"업데이트 실패: {matched_post['title']} / 오류: {e}")

            self.log("=== 쿠팡 상품 삽입 종료 ===\n")
        except Exception as e:
            self.log(f"전체 오류: {e}")

    def auto_link(self):
        self.log("=== 관련 글 링크 자동 연결 시작 (고정 매핑표 사용) ===")
        try:
            service = get_service()
            blog_id = get_blog_id(service)

            posts = []
            request = service.posts().list(blogId=blog_id, maxResults=500)
            while request is not None:
                response = request.execute()
                posts.extend(response.get("items", []))
                request = service.posts().list_next(request, response)

            # 실제 발행된 URL을 여기서 확인해서 매핑 (본인 블로그 주소 기준으로 이미 채워둠)
            base = "https://bangpharmacy.blogspot.com/2026/07/"
            LINK_MAP = {
                "유산균 먹으면 좋은 점 총정리 - 효능, 부작용, 연령별·성별 고르는 법": base + "blog-post_04.html",
                "프로바이오틱스(유산균) 완전정리 - 효능, 부작용, 고르는 법": base + "blog-post_04.html",
                "연령별 프로바이오틱스 완전정리": base + "blog-post_675.html",
                "연령별 프로바이오틱스(유산균) 완전정리": base + "blog-post_675.html",
                "성별 프로바이오틱스 완전정리": base + "blog-post_350.html",
                "성별 프로바이오틱스(유산균) 완전정리": base + "blog-post_350.html",
                "키즈 유산균 브랜드별 CFU 함량·가격 비교": base + "cfu.html",
                "키즈 유산균 브랜드별 CFU·가격 비교": base + "cfu.html",
                "청소년(주니어) 유산균 비교": base + "blog-post_676.html",
                "청소년 유산균 추천": base + "blog-post_676.html",
                "성인 유산균 비교": base + "blog-post_447.html",
                "성인 유산균 고르는 법": base + "blog-post_447.html",
                "시니어 유산균 비교": base + "4060.html",
                "시니어(부모님) 유산균 추천": base + "4060.html",
                "임산부·수유부 유산균 비교": base + "blog-post_92.html",
                "임산부·수유부 유산균": base + "blog-post_92.html",
                "갱년기 여성 유산균 비교": base + "yt1.html",
                "갱년기 여성 유산균": base + "yt1.html",
                "여성 질건강 유산균 비교": base + "urex.html",
                "여성 질건강 유산균": base + "urex.html",
                "다이어트 유산균 비교": base + "bnr17-vs-hy7601ky1032.html",
                "남성 건강 유산균 비교": base + "blog-post_730.html",
                "남성 건강 유산균": base + "blog-post_730.html",
            }

            suffixes = [" (링크 삽입)", " (링크, 준비중)", " (링크)"]

            for post in posts:
                post_id = post["id"]
                title = post["title"]
                content = post["content"]
                original_content = content

                for phrase, url in LINK_MAP.items():
                    for suffix in suffixes:
                        target = phrase + suffix
                        if target in content:
                            replacement = f'<a href="{url}">{phrase}</a>'
                            content = content.replace(target, replacement)

                if content != original_content:
                    try:
                        service.posts().update(
                            blogId=blog_id, postId=post_id,
                            body={"kind": "blogger#post", "title": title, "content": content}
                        ).execute()
                        self.log(f"링크 연결 완료: {title}")
                    except Exception as e:
                        self.log(f"업데이트 실패: {title} / 오류: {e}")
                else:
                    self.log(f"변경 없음 (링크 대상 텍스트 없음): {title}")

            self.log("=== 관련 글 링크 자동 연결 종료 ===\n")
        except Exception as e:
            self.log(f"전체 오류: {e}")

    def list_posts(self):
        self.log("=== 전체 글 목록 조회 시작 ===")
        try:
            service = get_service()
            blog_id = get_blog_id(service)

            posts = []
            request = service.posts().list(blogId=blog_id, maxResults=500, fetchBodies=False)
            while request is not None:
                response = request.execute()
                posts.extend(response.get("items", []))
                request = service.posts().list_next(request, response)

            # 게시일 오래된 순으로 정렬 (먼저 쓴 글이 위로)
            posts.sort(key=lambda p: p.get("published", ""))

            self.log(f"전체 글 {len(posts)}개\n")
            lines = []
            for i, post in enumerate(posts, 1):
                title = post["title"]
                url = post["url"]
                line = f"{i}. {title}\n   {url}"
                self.log(line)
                lines.append(line)

            # 파일로도 저장
            with open("post_list.txt", "w", encoding="utf-8") as f:
                f.write("\n".join(lines))
            self.log("\npost_list.txt 파일로도 저장했습니다.")
            self.log("=== 전체 글 목록 조회 종료 ===\n")
        except Exception as e:
            self.log(f"전체 오류: {e}")

    def publish_posts(self):
        self.log("=== 새 글 발행 시작 ===")
        try:
            if not os.path.exists(POSTED_FOLDER):
                os.makedirs(POSTED_FOLDER)
            service = get_service()
            blog_id = get_blog_id(service)
            self.log(f"블로그 ID 확인 완료: {blog_id}")

            files = sorted(glob.glob(os.path.join(POSTS_FOLDER, "*.txt")))
            if not files:
                self.log("발행할 글이 posts 폴더에 없습니다.")
                return

            for filepath in files:
                title, labels, body = parse_post_file(filepath)
                if not title or not body:
                    self.log(f"건너뜀 (형식 오류): {filepath}")
                    continue
                try:
                    post_body = {
                        "kind": "blogger#post",
                        "title": title,
                        "content": body,
                        "labels": labels,
                    }
                    result = service.posts().insert(blogId=blog_id, body=post_body, isDraft=False).execute()
                    url = result.get("url")
                    self.log(f"발행 완료: {title}\n  -> {url}")
                    shutil.move(filepath, os.path.join(POSTED_FOLDER, os.path.basename(filepath)))
                except Exception as e:
                    self.log(f"발행 실패: {title}\n  오류: {e}")
            self.log("=== 새 글 발행 종료 ===\n")
        except Exception as e:
            self.log(f"전체 오류: {e}")

    def fix_disclosure(self):
        self.log("=== 쿠팡 문구 위치 수정 시작 ===")
        try:
            service = get_service()
            blog_id = get_blog_id(service)

            posts = []
            request = service.posts().list(blogId=blog_id, maxResults=500)
            while request is not None:
                response = request.execute()
                posts.extend(response.get("items", []))
                request = service.posts().list_next(request, response)

            self.log(f"전체 글 {len(posts)}개 확인됨")

            for post in posts:
                post_id = post["id"]
                title = post["title"]
                content = post["content"]

                # 기존 쿠팡 고지 문구 패턴들을 찾아서 제거
                changed = False
                markers = [
                    "이 포스팅은 쿠팡 파트너스 활동의 일환으로",
                ]
                new_content = content
                for marker in markers:
                    if marker in new_content:
                        # <p>...marker...</p> 형태를 통째로 제거 시도
                        start = new_content.find("<p>", max(new_content.find(marker) - 10, 0))
                        end = new_content.find("</p>", new_content.find(marker))
                        if start != -1 and end != -1 and start < new_content.find(marker):
                            new_content = new_content[:start] + new_content[end + 4:]
                            changed = True
                        elif "<div" in new_content[:new_content.find(marker)][-200:]:
                            # 이미 div로 감싸진 경우는 건드리지 않음 (이미 처리됨으로 간주)
                            pass

                if changed:
                    new_content = new_content.strip() + "\n\n" + COUPANG_DISCLOSURE_SMALL
                    try:
                        service.posts().update(
                            blogId=blog_id, postId=post_id,
                            body={"kind": "blogger#post", "title": title, "content": new_content}
                        ).execute()
                        self.log(f"수정 완료: {title}")
                    except Exception as e:
                        self.log(f"수정 실패: {title} / 오류: {e}")
                else:
                    self.log(f"건너뜀 (해당 없음 또는 이미 처리됨): {title}")

            self.log("=== 쿠팡 문구 위치 수정 종료 ===\n")
        except Exception as e:
            self.log(f"전체 오류: {e}")


if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
